<?php

return array(

	"loginTitle" => "Please log in to continue.",
	"loginTitle2" => "Please fill this form and then press Send button to continue. ",
	"un_placeholder" => "Write username here",
	"pw_placeholder" => "Write password here",
	"your_un" => "Your username",
	"your_pw" => "Your password",
	"sub_button" => "Login to this site",
	 "error" => "Error: ",
	 "note" =>"Note: Maximum 50 characters, only contains letters of english alphabet, numbers and _ ? ! characters.",
	 "auth_error" => "Invalid username+password combination. "

);
