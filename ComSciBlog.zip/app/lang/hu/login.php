<?php

return array(

	"loginTitle" => "A folytatáshoz bejelentkezés szükséges.",
	"loginTitle2" => "Kérem töltse ki az alábbi űrlapot a bejelentkezéshez! ",
	"un_placeholder" => "Írja ide a felhasználónevét",
	"pw_placeholder" => "Írja ide a jelszavát",
	"your_un" => "A neve: ",
	"your_pw" => "Jelszó:",
	"sub_button" => "Bejelentkezés",
	 "error" => "Hiba: ",
	 "note" =>"Figyelem: Legyfeljebb 50 karakter hosszú lehet, és csak az angol ábécé betűit, számokat valamint _ ? ! karaktereket tartalmazhat.",
	 "auth_error" => "Helyetelen felhasználónév jelszó páros. "

);
